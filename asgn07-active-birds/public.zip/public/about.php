<?php 
  require_once('../private/initialize.php');
  $page_title = 'About'; 
  include(SHARED_PATH . '/public_header.php'); 
?>

    <h2>About</h2>
    <p>This site lists some of the common birds of Western NC.</p>

<?php include(SHARED_PATH . '/public_footer.php'); ?>
